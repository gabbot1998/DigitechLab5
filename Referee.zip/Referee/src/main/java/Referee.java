package main;

public class Referee {
    private String[][] board;
    private static final String UNDECIDED = "Undecided";
    private static final int CORRECT_LENGTH = 17;

    public Referee(String[][] board) {
        assert board.length == 3 && board[0].length == 3 && board[1].length == 3&& board[2].length == 3 : "Board is the wrong size";
        this.board = board;

    }

    public Referee(String board) {
        this.board = parse(board);
    }

    public String checkWinner() {
        String winner = UNDECIDED;

        winner = checkHorizontal();

        winner = winner.equals(UNDECIDED) ?
                 checkVertical() : winner;

        winner = winner.equals(UNDECIDED) ?
                 checkDiagonal() : winner;

        return winner;
    }

    private String checkHorizontal() {
        String winner = UNDECIDED;

        for(String[] row : board) {
            if(checkThreeInARow(row[0], row[1], row[2])) {
                winner = row[0];
                break;
            }
        }

        return winner;
    }

    private String checkVertical() {
        String winner = UNDECIDED;

        for(int i = 0; i < 3; i++) {
            if(checkThreeInARow(board[0][i], board[1][i], board[2][i])) {
                winner = board[0][i];
                break;
            }
        }

        return winner;
    }

    private String checkDiagonal() {
        String winner = UNDECIDED;

        winner = checkThreeInARow(board[0][0], board[1][1], board[2][2]) ?
                 board[0][0] : winner;

        winner = checkThreeInARow(board[0][2], board[1][1], board[2][0]) ?
                 board[0][2] : winner;

        return winner;
    }


    private Boolean checkThreeInARow(String one, String two, String three) {
        return !one.equals(" ") && one.equals(two) && two.equals(three);
    }

    private String[][] parse(String input) {
        //The correct length is 17.
        assert input.length() == CORRECT_LENGTH : "Board is the wrong size";

        String[][] board = new String[3][3];
        String[] placedPieces = input.split(",");

        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 3; j++) {
                board[i][j] = placedPieces[3 * i + j];
            }
        }

        return board;
    }

    public void print() {
        for (String[] row : board) {
            for (String piece : row) {

                System.out.print(piece);

            }
            System.out.println();
        }
        System.out.println();
    }

}
