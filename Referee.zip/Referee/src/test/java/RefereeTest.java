import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import main.Referee;

class RefereeTest {
    private String[][] board;

    @BeforeEach
    void setUp() {
        this.board = new String[3][3];
        board[0][0] = " ";
        board[0][1] = " ";
        board[0][2] = " ";

        board[1][0] = " ";
        board[1][1] = " ";
        board[1][2] = " ";

        board[2][0] = " ";
        board[2][1] = " ";
        board[2][2] = " ";

    }

    @Test
    void printBoard() {
        //Setting up the board for this test. The board is not a valid one.
        board[0][0] = "x";
        board[0][1] = "x";
        board[0][2] = "x";

        board[1][0] = "o";
        board[1][1] = "o";
        board[1][2] = "o";

        board[2][0] = "x";
        board[2][1] = "x";
        board[2][2] = "x";

        Referee test = new Referee(board);
        test.print();

    }

    @Test
    void checkIfUndecided() {
        //Setting up the board for this test. The board is not a valid one.
        board[0][0] = " ";
        board[0][1] = " ";
        board[0][2] = "x";

        board[1][0] = "o";
        board[1][1] = "x";
        board[1][2] = " ";

        board[2][0] = " ";
        board[2][1] = " ";
        board[2][2] = "x";

        Referee test = new Referee(board);
        assertEquals("Undecided", test.checkWinner());
    }

    @Test
    void checkHorizontalWinFirstRow() {
        //Setting up a board with a horizontal win.
        board[0][0] = "x";
        board[0][1] = "x";
        board[0][2] = "x";

        board[1][0] = " ";
        board[1][1] = " ";
        board[1][2] = " ";

        board[2][0] = " ";
        board[2][1] = " ";
        board[2][2] = " ";

        Referee test = new Referee(board);
        assertEquals("x", test.checkWinner());
    }

    @Test
    void checkHorizontalWinSecondRow() {
        //Setting up a board with a horizontal win.
        board[0][0] = " ";
        board[0][1] = " ";
        board[0][2] = " ";

        board[1][0] = "x";
        board[1][1] = "x";
        board[1][2] = "x";

        board[2][0] = " ";
        board[2][1] = " ";
        board[2][2] = " ";

        Referee test = new Referee(board);
        assertEquals("x", test.checkWinner());
    }

    @Test
    void checkHorizontalWinThirdRow() {
        //Setting up a board with a horizontal win.
        board[0][0] = " ";
        board[0][1] = " ";
        board[0][2] = " ";

        board[1][0] = " ";
        board[1][1] = " ";
        board[1][2] = " ";

        board[2][0] = "x";
        board[2][1] = "x";
        board[2][2] = "x";

        Referee test = new Referee(board);
        assertEquals("x", test.checkWinner());
    }

    @Test
    void checkVerticalWinFirst() {
        //Setting up a board with a horizontal win.
        board[0][0] = "x";
        board[0][1] = " ";
        board[0][2] = " ";

        board[1][0] = "x";
        board[1][1] = " ";
        board[1][2] = " ";

        board[2][0] = "x";
        board[2][1] = " ";
        board[2][2] = " ";

        Referee test = new Referee(board);
        assertEquals("x", test.checkWinner());
    }

    @Test
    void checkVerticalWinSecond() {
        //Setting up a board with a horizontal win.
        board[0][0] = " ";
        board[0][1] = "o";
        board[0][2] = " ";

        board[1][0] = " ";
        board[1][1] = "o";
        board[1][2] = " ";

        board[2][0] = " ";
        board[2][1] = "o";
        board[2][2] = " ";

        Referee test = new Referee(board);
        assertEquals("o", test.checkWinner());
    }

    @Test
    void checkVerticalWinThird() {
        //Setting up a board with a horizontal win.
        board[0][0] = " ";
        board[0][1] = " ";
        board[0][2] = "x";

        board[1][0] = " ";
        board[1][1] = " ";
        board[1][2] = "x";

        board[2][0] = " ";
        board[2][1] = " ";
        board[2][2] = "x";

        Referee test = new Referee(board);
        assertEquals("x", test.checkWinner());
    }

    @Test
    void checkDiagonalleftToRight() {
        //Setting up a board with a horizontal win.
        board[0][0] = "o";
        board[0][1] = "x";
        board[0][2] = "x";

        board[1][0] = "x";
        board[1][1] = "o";
        board[1][2] = " ";

        board[2][0] = "x";
        board[2][1] = " ";
        board[2][2] = "o";

        Referee test = new Referee(board);
        assertEquals("o", test.checkWinner());
    }

    @Test
    void checkDiagonallRightToLeft() {
        //Setting up a board with a horizontal win.
        board[0][0] = "o";
        board[0][1] = "x";
        board[0][2] = "x";

        board[1][0] = "o";
        board[1][1] = "x";
        board[1][2] = " ";

        board[2][0] = "x";
        board[2][1] = " ";
        board[2][2] = "0";

        Referee test = new Referee(board);
        test.print();
        assertEquals("x", test.checkWinner());
    }

    @Test
    void fullGameNoWinner() {
        Referee test = new Referee(board);
        board[1][1] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[0][0] = "o";
        assertEquals("Undecided", test.checkWinner());
        board[2][0] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[0][2] = "o";
        assertEquals("Undecided", test.checkWinner());
        board[0][1] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[2][1] = "o";
        assertEquals("Undecided", test.checkWinner());
        board[2][2] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[1][0] = "o";
        assertEquals("Undecided", test.checkWinner());
        board[1][2] = "x";
        assertEquals("Undecided", test.checkWinner());
        test.print();
        System.out.println();
    }

    @Test
    void wierdBug() {
        Referee test = new Referee(board);
        board[1][1] = "x";
        board[0][0] = "o";
        board[2][0] = "x";
        board[0][2] = "x";
        board[0][1] = "x";
        test.print();
        assertEquals("x", test.checkWinner());
        board[2][1] = "o";
        board[2][2] = "x";
        board[1][0] = "o";
        board[1][2] = "x";
        assertEquals("x", test.checkWinner());
        test.print();
    }

    @Test
    void fullGameOWinner() {
        Referee test = new Referee(board);
        board[1][1] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[0][0] = "o";
        assertEquals("Undecided", test.checkWinner());
        board[2][0] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[0][2] = "o";
        assertEquals("Undecided", test.checkWinner());
        board[2][2] = "x";
        assertEquals("Undecided", test.checkWinner());
        board[0][1] = "o";
        assertEquals("o", test.checkWinner());
        board[1][2] = "x";
        assertEquals("o", test.checkWinner());
        board[1][0] = "o";
        assertEquals("o", test.checkWinner());
        board[2][1] = "x";
        assertEquals("o", test.checkWinner());
        test.print();
        System.out.println();
    }

    @Test
    void tryBoardTooBig() {
        String[][] tooBig = new String[4][4];
        assertThrows(AssertionError.class, () -> {Referee test = new Referee(tooBig);});
    }

    @Test
    void testBoradStringTooBig() {
        String tooBig = "1,2,3,4,5,6,7,8,9,1";
        assertThrows(AssertionError.class, () -> {Referee test = new Referee(tooBig);});
    }

    @Test
    void testTheParser() {
        String board = "x, ,o,o,x, ,o,o,x";
        Referee test = new Referee(board);
        assertEquals("x", test.checkWinner());
        test.print();
    }

}
